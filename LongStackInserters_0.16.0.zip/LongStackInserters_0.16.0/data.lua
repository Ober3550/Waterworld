longstack = util.table.deepcopy(data.raw["inserter"]["long-handed-inserter"])
longstack.name = "long-stack-inserter"
longstack.icon = "__LongStackInserters__/graphics/icons/long-stack-inserter.png"
longstack.stack = true
longstack.minable.result = "long-stack-inserter"
longstack.energy_per_movement = data.raw["inserter"]["stack-inserter"].energy_per_movement
longstack.energy_per_rotation = data.raw["inserter"]["stack-inserter"].energy_per_rotation
longstack.rotation_speed = data.raw["inserter"]["stack-inserter"].rotation_speed
longstack.extension_speed = data.raw["inserter"]["stack-inserter"].extension_speed
if arm_colour then
  longstack.hand_base_picture = data.raw["inserter"]["stack-inserter"].hand_base_picture
end
longstack.hand_closed_picture = data.raw["inserter"]["stack-inserter"].hand_closed_picture
longstack.hand_open_picture = data.raw["inserter"]["stack-inserter"].hand_open_picture

data:extend({
{
    type = "recipe",
    name = "long-stack-inserter",
    enabled = false,
    ingredients =
    {
      {"stack-inserter", 1},
      {"long-handed-inserter", 1}
    },
    result = "long-stack-inserter",
    requester_paste_multiplier = 4
},
{
    type = "item",
    name = "long-stack-inserter",
    icon = "__LongStackInserters__/graphics/icons/long-stack-inserter.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "inserter",
    order = "f[stack-inserter]z",
    place_result = "long-stack-inserter",
    stack_size = 50
},
longstack
})
table.insert(
  data.raw["technology"]["stack-inserter"].effects,
  {type = "unlock-recipe",recipe = "long-stack-inserter"})