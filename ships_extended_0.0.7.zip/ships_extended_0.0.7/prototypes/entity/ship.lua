data:extend(
{
	{
		type = "car",
		name = "basic-ship",
		icon = "__ships_extended__/graphics/icons/ship.png",
		icon_size = 32,
		flags = {"pushable", "placeable-neutral", "player-creation", "placeable-off-grid"},
		minable = {mining_time = 10, result = "basic-ship"},
		max_health = 2000,
		corpse = "big-remnants",
		dying_explosion = "big-explosion",
		energy_per_hit_point = 0.5,
		resistances =
		{
			{
				type = "fire",
				decrease = 15,
				percent = 80
			},
			{
				type = "physical",
				decrease = 5,
				percent = 10
			},
			{
				type = "impact",
				decrease = 50,
				percent = 80
			},
			{
				type = "acid",
				decrease = 6,
				percent = 20
			}
		},
		collision_box = {{-1.35, -3.1}, {1.35, 3.1}},
		selection_box = {{-1.35, -3.1}, {1.35, 3.1}},
		drawing_box = {{-1.35, -3.1}, {1.35, 3.1}},
		collision_mask = {'ground-tile', 'object-layer'},
		effectivity = 0.5,
		braking_power = "500kW",
		burner =
		{
			effectivity = 0.65,
			fuel_inventory_size = 4,
			smoke =
			{
				{
					name = "tank-smoke",
					deviation = {0.55, 0.55},
					frequency = 20,
					position = {0, 2.5},
					starting_frame = 0,
					starting_frame_deviation = 60
				}
			}
		},
		consumption = "1000kW",
		terrain_friction_modifier = 0.1,
		friction = 0.001,
		light =
		{
			{
				type = "oriented",
				minimum_darkness = 0.3,
				picture =
				{
					filename = "__core__/graphics/light-cone.png",
					priority = "medium",
					scale = 2.5,
					width = 200,
					height = 200
				},
				shift = {-0.8, -14},
				size = 2,
				intensity = 0.6
			},
			{
				type = "oriented",
				minimum_darkness = 0.3,
				picture =
				{
					filename = "__core__/graphics/light-cone.png",
					priority = "medium",
					scale = 2,
					width = 200,
					height = 200
				},
				shift = {0.8, -14},
				size = 2.5,
				intensity = 0.6
			}
		},
		animation =
		{
			layers =
			{
				{
					width = 360,
					height = 249,
					frame_count = 1,
					direction_count = 72,
					shift = {-0.0, -0.58125},
					animation_speed = 8,
					max_advance = 1,
					scale = 1.5,
					stripes =
					{
						{
						 filename = "__ships_extended__/graphics/entity/shipQ1.png",
						 width_in_frames = 3,
						 height_in_frames = 6,
						},

						{
						 filename = "__ships_extended__/graphics/entity/shipQ2.png",
						 width_in_frames = 3,
						 height_in_frames = 6,
						},

						{
						 filename = "__ships_extended__/graphics/entity/shipQ3.png",
						 width_in_frames = 3,
						 height_in_frames = 6,
						},

						{
						 filename = "__ships_extended__/graphics/entity/shipQ4.png",
						 width_in_frames = 3,
						 height_in_frames = 6,
						}
					}
				}
			}
		},
		turret_animation =
		{
			layers =
			{
				--[[{
					filename = "__base__/graphics/entity/tank/turret.png",
					line_length = 8,
					width = 92,
					height = 69,
					frame_count = 1,
					direction_count = 64,
					shift = {-0.15625, -1.07812},
					animation_speed = 8,
				},
				{
					filename = "__base__/graphics/entity/tank/turret-mask.png",
					line_length = 8,
					width = 38,
					height = 29,
					frame_count = 1,
					apply_runtime_tint = true,
					direction_count = 64,
					shift = {-0.15625, -1.23438},
				},
				{
					filename = "__base__/graphics/entity/tank/turret-shadow.png",
					line_length = 8,
					width = 95,
					height = 67,
					frame_count = 1,
					draw_as_shadow = true,
					direction_count = 64,
					shift = {1.70312, 0.640625},
				}]]
			}
		},
		turret_rotation_speed = 0.35 / 60,
		turret_return_timeout = 300,
		stop_trigger_speed = 0.2,
		sound_no_fuel =
		{
			{
				filename = "__base__/sound/fight/tank-no-fuel-1.ogg",
				volume = 0.6
			},
		},
		stop_trigger =
		{
			{
				type = "play-sound",
				sound =
				{
					{
						filename = "__base__/sound/car-breaks.ogg",
						volume = 0.6
					},
				}
			},
		},
		sound_minimum_speed = 0.12;
		vehicle_impact_sound =	{ filename = "__base__/sound/car-metal-impact.ogg", volume = 0.9 },
		working_sound =
		{
			sound =
			{
				filename = "__base__/sound/steam-engine-90bpm.ogg",
				volume = 0.5
			},
			activate_sound =
			{
				filename = "__base__/sound/fight/tank-engine-start.ogg",
				volume = 0.4
			},
			deactivate_sound =
			{
				filename = "__base__/sound/fight/tank-engine-stop.ogg",
				volume = 0.4
			},
			match_speed_to_activity = true,
		},
		open_sound = { filename = "__base__/sound/car-door-open.ogg", volume=0.4 },
		close_sound = { filename = "__base__/sound/car-door-close.ogg", volume = 0.4 },
		rotation_speed = 0.0013,
		tank_driving = true,
		weight = 20000,
		inventory_size = 180,
		guns = {},
	},

	{
		type = "item",
		name = "basic-ship",
		icon = "__ships_extended__/graphics/icons/ship.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		order = "b[personal-transport]-b[car]",
		place_result = "basic-ship",
		stack_size = 1
	},
	{
		type = "item",
		name = "basic-ship-2",
		icon = "__ships_extended__/graphics/icons/ship-2.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		order = "b[personal-transport]-b[car]",
		place_result = "basic-ship-2",
		stack_size = 1
	},
	{
		type = "item",
		name = "basic-ship-3",
		icon = "__ships_extended__/graphics/icons/ship-3.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "transport",
		order = "b[personal-transport]-b[car]",
		place_result = "basic-ship-3",
		stack_size = 1
	}
})
local ship2 = table.deepcopy(data.raw["car"]["basic-ship"])
ship2.name = "basic-ship-2"
ship2.minable = {mining_time = 10, result = "basic-ship-2"}
ship2.max_health = 3000
ship2.effectivity = 0.75
ship2.braking_power = "400kW"
ship2.burner.effectivity = 0.75
ship2.burner.fuel_inventory_size = 5
ship2.consumption = "4000kW"
ship2.rotation_speed = 0.0026
ship2.weight = 240000
ship2.inventory_size = 160
ship2.icon = "__ships_extended__/graphics/icons/ship-2.png"

local ship3 = table.deepcopy(data.raw["car"]["basic-ship"])
ship3.name = "basic-ship-3"
ship3.minable = {mining_time = 10, result = "basic-ship-3"}
ship3.max_health = 4000
ship3.effectivity = 1
ship3.braking_power = "600kW"
ship3.burner.effectivity = 1
ship3.burner.fuel_inventory_size = 6
ship3.consumption = "6000kW"
ship3.rotation_speed = 0.0039
ship3.weight = 360000
ship3.inventory_size = 200
ship3.icon = "__ships_extended__/graphics/icons/ship-3.png"
ship3.guns = { "ship-cannon", "ship-machine-gun" }
data:extend({ship2, ship3})

data:extend({
	{
		type = "recipe",
		name = "basic-ship",
		enabled = false,
		category = "crafting",
		energy_required = 120,
		ingredients =
			{
				{"engine-unit",45},
				{"advanced-circuit",150},
				{"iron-gear-wheel",150},
				{"iron-plate",400},
				{"steel-plate",200},
				{"copper-plate",300}
			},
		result = "basic-ship"
	},
	{
		type = "recipe",
		name = "basic-ship-2",
		enabled = false,
		category = "crafting",
		energy_required = 240,
		ingredients =
			{
				{"basic-ship",1},
			  {"processing-unit", 200}
			},
		result = "basic-ship-2"
	},
	{
		type = "recipe",
		name = "basic-ship-3",
		enabled = false,
		category = "crafting",
		energy_required = 480,
		ingredients =
			{
				{"basic-ship-2",1},
				  {"plastic-bar", 400},
			},
		result = "basic-ship-3"
	},
})
if bobmods and bobmods.plates then
	table.insert(data.raw.recipe["basic-ship-2"].ingredients, {"titanium-plate", 400})
	table.insert(data.raw.recipe["basic-ship-2"].ingredients, {"titanium-gear-wheel", 200})
	table.insert(data.raw.recipe["basic-ship-2"].ingredients, {"titanium-bearing", 200})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"tungsten-plate", 500})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"nitinol-gear-wheel", 300})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"nitinol-bearing", 300})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"advanced-processing-unit", 300})
else
	table.insert(data.raw.recipe["basic-ship-2"].ingredients, {"steel-plate", 400})
	table.insert(data.raw.recipe["basic-ship-2"].ingredients, {"iron-gear-wheel", 200})
	table.insert(data.raw.recipe["basic-ship-2"].ingredients, {"iron-plate", 200})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"steel-plate", 500})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"iron-plate", 300})
	table.insert(data.raw.recipe["basic-ship-3"].ingredients, {"processing-unit", 500})
end