return 
{
	oil_freq = 
	{
		none = "None",
		minimal = "Minimal",
		v_v_low = "Very very low",
		v_low = "Very low",
		low = "Low",
		normal = "Normal",
		high = "High",
		v_high = "Very High"
	},
	oil_rich =
	{
		v_poor = "Very poor",
		poor = "Poor",
		regular = "Regular",
		good = "Good",
		v_good = "Very Good"
	}
}
