
function CreateBridge(entity)
	pos = entity.position
	dir = entity.direction
	if (dir==defines.direction.north or dir==defines.direction.south) then
		for x=-2,2,1 do
			 
		end 
	else
	end
end